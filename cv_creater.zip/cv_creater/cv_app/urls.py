from django.urls import path
from.import views


urlpatterns= [
    path('',views.index,name='index'),
    path('sign',views.sign,name='sign'),
    path('sample',views.sample,name='sample'),
    path('perfer',views.perfer,name='perfer'),
    path('detail',views.detail,name='detail'),
    path('tool',views.tool,name='tool'),
    path('last',views.last,name='last'),
    path('register',views.register,name='register'),
    path('logout_view',views.logout_view,name='logout_view'),
    path('base',views.base,name='base'),
]
