from django.shortcuts import render,redirect
from django.contrib import messages
from cv_app.models import Signin,Perfer,Detail,Review,enquiry

# Create your views here.


def index(request):
    review=Review.objects.all()
    return render(request,'index.html',{'review':review})

def base(request):
    review=Review.objects.all()
    return render(request,'base.html',{'review':review})



def sample(request):
    if 'user' in request.session:
        return render(request,'sample.html')
    else :
        return render(request,'signin.html')

def perfer(request):
    if request.method=='POST':
        cv_names=request.POST.get('cv_name')
        titles=request.POST.get('title')
        data=Perfer(cv_name=cv_names,title=titles)
        data.save()
        return redirect('detail')
    else:
        return render(request,'perfer.html')

def detail(request):
    if request.method=='POST':
        image=request.FILES['imag']
        firstname_a=request.POST.get('Firstname')
        lastname_a=request.POST.get('Lastname')
        phonenumber_a=request.POST.get('Phonenumber')
        email_a=request.POST.get('Email')
        Jobtitle_a=request.POST.get('Jobtitle')
        state_a=request.POST.get('state')
        City_a=request.POST.get('City')
        Pincode_a=request.POST.get('Pincode')
        Address_a=request.POST.get('Adddress')
        summary_a=request.POST.get('summary')
        Jobtitle_c=request.POST.get('Job_title')
        date_a=request.POST.get('date1')
        date_c=request.POST.get('date2')
        city_c=request.POST.get('city2')
        Description_a=request.POST.get('Description')
        school_a=request.POST.get('school')
        Degree_a=request.POST.get('Degree')
        date_d=request.POST.get('date3')
        date_s=request.POST.get('date4')
        Description_c=request.POST.get('Description2')
        skill_a=request.POST.get('skill')
        language_a=request.POST.get('language')
        Jobtitle_s=request.POST.get('Job_title1')
        employee_c=request.POST.get('employee')
        date_q=request.POST.get('date5')
        date_w=request.POST.get('date6')
        city_q=request.POST.get('city3')
        data=Detail(city3=city_q,imag=image,Job_title1=Jobtitle_s,employee=employee_c,date5=date_q,date6=date_w,skill=skill_a,language=language_a,Description2=Description_c,date3=date_d,date4=date_s,school=school_a,Degree=Degree_a,Description=Description_a,date1=date_a,date2=date_c,city2=city_c,Firstname=firstname_a,Lastname=lastname_a,Phonenumber=phonenumber_a,Email=email_a,Jobtitle=Jobtitle_a,state=state_a,City=City_a,Address=Address_a,Pincode=Pincode_a,summary=summary_a,Job_title=Jobtitle_c)
        data.save()
        return redirect('tool')
    else:
        return render(request,'details.html')
    

def tool(request):
    tool=Detail.objects.all()
    return render(request,'tool.html',{'tool':tool})



def last(request):
    if 'user' in request.session:
        last=Signin.objects.all()
        if request.method=="POST":
            name_r=request.POST.get('name')
            email_a=request.POST.get('email')
            phonenumber_a=request.POST.get('phone')
            summary_a=request.POST.get('summary')
            data=enquiry(name=name_r,email=email_a,phone=phonenumber_a,summary=summary_a)
            data.save()
            return redirect('last')
        else:
            return render(request,'lastpage.html',{'last':last})
    else:
        return render(request,'signin.html')

        

def register(request):
    if request.method=='POST':
        image1=request.FILES['img']
        firstname_a=request.POST.get('Firstname')
        lastname_a=request.POST.get('Lastname')
        place_a=request.POST.get('place')
        title_a=request.POST.get('title')
        dob_a=request.POST.get('dob')
        phonenumber_a=request.POST.get('Phonenumber')
        email_a=request.POST.get('Email')
        password_a=request.POST.get('Password')
        password_c=request.POST.get('Password2')
        if password_a==password_c:
            data=Signin(Firstname=firstname_a,Lastname=lastname_a,Phonenumber=phonenumber_a,Email=email_a,Password=password_a,Password2=password_c,title=title_a,place=place_a,dob=dob_a,img=image1)
            data.save()
            messages.success(request,'account register successfully')
            return redirect('sign')
        else:
            messages.warning(request,'Password mismatch')
            return redirect('register')
    else:
        return render(request,'register.html')
    
   

def sign(request):
    if request.method=="POST":
        email_a=request.POST.get('Email')
        password_c=request.POST.get('Password')
        check_user=Signin.objects.filter(Email=email_a,Password=password_c)
        if check_user:
            request.session['user']=email_a
            return redirect('base')
        else:
            messages.warning(request,'Username or Password are invalid')
            return redirect('sign')
    else:
        return render(request,'signin.html')

def logout_view(request):
    try:
        del request.session['user']
    except:
        return redirect('sign')
    return render(request,'index.html')