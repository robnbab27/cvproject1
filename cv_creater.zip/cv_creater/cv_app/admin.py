from django.contrib import admin
from cv_app.models import Signin,Perfer,Detail,Review,enquiry

# Register your models here.
admin.site.register(Signin)
admin.site.register(Perfer)
admin.site.register(Detail)
admin.site.register(Review)
admin.site.register(enquiry)