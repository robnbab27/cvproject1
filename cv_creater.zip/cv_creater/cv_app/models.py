from django.db import models

# Create your models here.
class Signin(models.Model):
    img=models.ImageField(upload_to='media',null=True,blank=False)
    Firstname=models.CharField(max_length=50,null=True,blank=False)
    Lastname=models.CharField(max_length=50,null=True,blank=False)
    title=models.CharField(max_length=50,null=True,blank=False)
    Phonenumber=models.IntegerField(null=True,blank=False)
    place=models.CharField(max_length=50,null=True,blank=False)
    dob=models.DateField(null=True,blank=False)
    Email=models.CharField(max_length=50,null=True,blank=False)
    Username=models.CharField(max_length=50,null=True,blank=False)
    Password=models.CharField(max_length=50,null=True,blank=False)
    Password2=models.CharField(max_length=50,null=True,blank=False)

class Perfer(models.Model):
    cv_name=models.CharField(max_length=50,null=True,blank=False)
    title=models.CharField(max_length=50,null=True,blank=False)

class Detail(models.Model):
    imag=models.ImageField(upload_to='media',null=True,blank=False)
    Jobtitle=models.CharField(max_length=50,null=True,blank=False)
    Firstname=models.CharField(max_length=50,null=True,blank=False)
    Lastname=models.CharField(max_length=50,null=True,blank=False)
    Phonenumber=models.IntegerField(null=True,blank=False)
    Email=models.CharField(max_length=50,null=True,blank=False)
    state=models.CharField(max_length=50,null=True,blank=False)
    City=models.CharField(max_length=50,null=True,blank=False)
    Pincode=models.IntegerField(null=True,blank=False)
    Address=models.CharField(max_length=50,null=True,blank=False)
    summary=models.CharField(max_length=100,null=True,blank=False)

    Job_title=models.CharField(max_length=100,null=True,blank=False)
    date1=models.DateTimeField(null=True,blank=True)
    date2=models.DateTimeField(null=True,blank=True)
    city2=models.CharField(max_length=50,null=True,blank=False)
    Description=models.CharField(max_length=100,null=True,blank=False)

    school=models.CharField(max_length=100,null=True,blank=False)
    Degree=models.CharField(max_length=100,null=True,blank=False)
    date3=models.DateField(max_length=100,null=True,blank=False)
    date4=models.DateField(max_length=100,null=True,blank=False)
    city3=models.CharField(max_length=50,null=True,blank=False)
    Description2=models.CharField(max_length=100,null=True,blank=False)

    skill=models.CharField(max_length=100,null=True,blank=False)
    language=models.CharField(max_length=100,null=True,blank=False)

    Job_title1=models.CharField(max_length=100,null=True,blank=False)
    employee=models.CharField(max_length=100,null=True,blank=False)
    date5=models.DateField(max_length=100,null=True,blank=False)
    date6=models.DateField(max_length=100,null=True,blank=False)
    city4=models.CharField(max_length=50,null=True,blank=False)


class Review(models.Model):
    images=models.ImageField(upload_to='media',null=True,blank=False)
    name=models.CharField(max_length=50,null=True,blank=False)
    username=models.CharField(max_length=50,null=True,blank=False)
    rate=models.IntegerField(null=True,blank=False)
    review=models.CharField(max_length=50,null=True,blank=False)

class enquiry(models.Model):
    name=models.CharField(max_length=50,null=True,blank=False)
    email=models.CharField(max_length=50,null=True,blank=False)
    phone=models.IntegerField(null=True,blank=False)
    summary=models.CharField(max_length=50,null=True,blank=False)